from crawler.calc_runner import run_calcs
from log_monitor.log_watcher import monitor_logs
from diff_analyzer.diff_analyzer import compare_outputs
from notifier.notifier import notify_status
from reporter.report_generator import generate_report

def main():
    print("▶️ Starting Smart Regression Agent...")
    run_calcs()
    monitor_logs()
    compare_outputs()
    notify_status()
    generate_report()

if __name__ == "__main__":
    main()