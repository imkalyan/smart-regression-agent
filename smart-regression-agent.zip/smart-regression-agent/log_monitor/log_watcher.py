def monitor_logs():
    print("🔍 Watching logs...")
    # TODO: Read logs, summarize with LLM or regex classification