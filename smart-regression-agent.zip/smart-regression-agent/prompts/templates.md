### 🪵 Log Summarization
"You are a log classification assistant. Given a log snippet, identify the error type and root cause..."

### 🧪 Diff Explanation
"You're comparing two margin outputs..."

### 📣 Summary Notification
"Summarize regression result for Slack message..."