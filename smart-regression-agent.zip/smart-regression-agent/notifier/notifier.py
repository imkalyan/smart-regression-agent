def notify_status():
    print("📬 Sending notifications...")
    # TODO: Push to Teams/Slack using webhook